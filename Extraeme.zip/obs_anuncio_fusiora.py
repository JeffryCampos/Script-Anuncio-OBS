import obspython as obs
import time
import math

# --- Configuraciones Globales ---
image_source_name = ""
text_content = ""
text_color = "ffffff"
font_data = None
align_mode = "center" # "left", "center", "right"
force_default_pos = True
interval_sec = 10
img_duration_sec = 4
txt_duration_sec = 4
slide_distance = 1000

# --- Estado de Animación ---
state = 0
state_start_time = 0
last_scene_name = ""

anim_slide_dur = 1.2
anim_flip_dur = 0.4

img_base_pos = obs.vec2()
img_base_scale = obs.vec2()
img_align = 0
bases_init = False
generated_text_name = "Fusiora_Ad_Text_Auto"

# --- Funciones de Easing ---
def ease_out_bounce(x):
    n1 = 7.5625
    d1 = 2.75
    if x < 1 / d1:
        return n1 * x * x
    elif x < 2 / d1:
        x -= 1.5 / d1
        return n1 * x * x + 0.75
    elif x < 2.5 / d1:
        x -= 2.25 / d1
        return n1 * x * x + 0.9375
    else:
        x -= 2.625 / d1
        return n1 * x * x + 0.984375

def ease_in_out_sine(x):
    return -(math.cos(math.pi * x) - 1.0) / 2.0

def ease_in_back(x):
    c1 = 1.70158
    c3 = c1 + 1.0
    return c3 * x * x * x - c1 * x * x

def hex_to_obs_color(hex_str):
    hex_str = hex_str.lstrip('#')
    if len(hex_str) != 6:
        return 0xffffffff
    b = int(hex_str[4:6], 16)
    g = int(hex_str[2:4], 16)
    r = int(hex_str[0:2], 16)
    return 0xff000000 | (b << 16) | (g << 8) | r

def setup_text_source(parent_scene):
    text_source = obs.obs_get_source_by_name(generated_text_name)
    settings = obs.obs_data_create()
    obs.obs_data_set_string(settings, "text", text_content)
    
    global font_data
    if font_data:
        obs.obs_data_set_obj(settings, "font", font_data)
    else:
        font_obj = obs.obs_data_create()
        obs.obs_data_set_string(font_obj, "face", "Arial")
        obs.obs_data_set_int(font_obj, "size", 72)
        obs.obs_data_set_int(font_obj, "flags", 1) # Bold
        obs.obs_data_set_obj(settings, "font", font_obj)
        obs.obs_data_release(font_obj)
    
    obs.obs_data_set_int(settings, "color1", hex_to_obs_color(text_color))
    obs.obs_data_set_int(settings, "color2", hex_to_obs_color(text_color))
    obs.obs_data_set_bool(settings, "outline", True)
    obs.obs_data_set_int(settings, "outline_size", 4)
    obs.obs_data_set_int(settings, "outline_color", 0xff000000)
    
    obs.obs_data_set_bool(settings, "bk_color_enable", True)
    obs.obs_data_set_int(settings, "bk_color", 0xff1a1a1a)
    obs.obs_data_set_int(settings, "bk_opacity", 220)
    
    # Text GDI+ v2 requires a string for alignment to correctly format multiline text
    global align_mode
    obs.obs_data_set_string(settings, "align", align_mode if align_mode else "center")

    if not text_source:
        text_source = obs.obs_source_create("text_gdiplus_v2", generated_text_name, settings, None)
    else:
        obs.obs_source_update(text_source, settings)
        
    txt_scene_item = obs.obs_scene_find_source(parent_scene, generated_text_name)
    if not txt_scene_item:
        txt_scene_item = obs.obs_scene_add(parent_scene, text_source)
        
    obs.obs_data_release(settings)
    obs.obs_source_release(text_source)
    return txt_scene_item

def center_of_item(item):
    source = obs.obs_sceneitem_get_source(item)
    w = obs.obs_source_get_width(source)
    h = obs.obs_source_get_height(source)
    pos = obs.vec2()
    scale = obs.vec2()
    obs.obs_sceneitem_get_pos(item, pos)
    obs.obs_sceneitem_get_scale(item, scale)
    align = obs.obs_sceneitem_get_alignment(item)
    
    cx, cy = pos.x, pos.y
    if align == 0: align = 5
    
    if (align & (1 << 0)): cx += (w * scale.x) / 2
    elif (align & (1 << 1)): cx -= (w * scale.x) / 2
    if (align & (1 << 2)): cy += (h * scale.y) / 2
    elif (align & (1 << 3)): cy -= (h * scale.y) / 2
        
    return cx, cy

def scale_horizontal_centered(item, base_pos, base_scale, source_w, align, scale_x_factor):
    scale = obs.vec2()
    scale.x = base_scale.x * scale_x_factor
    scale.y = base_scale.y
    obs.obs_sceneitem_set_scale(item, scale)
    
    pos = obs.vec2()
    pos.x = base_pos.x
    pos.y = base_pos.y
    
    if align == 0: align = 5
    if (align & (1 << 0)):
        diff_w = (source_w * base_scale.x) - (source_w * scale.x)
        pos.x += diff_w / 2
    elif (align & (1 << 1)):
        diff_w = (source_w * base_scale.x) - (source_w * scale.x)
        pos.x -= diff_w / 2
        
    obs.obs_sceneitem_set_pos(item, pos)

def animation_tick():
    global state, state_start_time, bases_init, last_scene_name

    if not image_source_name: return

    current_scene_source = obs.obs_frontend_get_current_scene()
    if not current_scene_source: return
    
    current_scene_name = obs.obs_source_get_name(current_scene_source)
    parent_scene = obs.obs_scene_from_source(current_scene_source)
    img_item = obs.obs_scene_find_source(parent_scene, image_source_name)
    
    if not img_item:
        obs.obs_source_release(current_scene_source)
        return
        
    txt_item = setup_text_source(parent_scene)
    
    now = time.time()
    
    if current_scene_name != last_scene_name:
        last_scene_name = current_scene_name
        state = 0
        state_start_time = now
        bases_init = False
        obs.obs_sceneitem_set_visible(img_item, False)
        obs.obs_sceneitem_set_visible(txt_item, False)
        obs.obs_source_release(current_scene_source)
        return

    if state_start_time == 0: state_start_time = now
    elapsed = now - state_start_time

    img_source = obs.obs_sceneitem_get_source(img_item)
    img_w = obs.obs_source_get_width(img_source)
    obs.obs_sceneitem_set_alignment(txt_item, 0) # Center=0

    if state == 0: # Esperando
        if not bases_init:
            obs.obs_sceneitem_set_visible(img_item, False)
            obs.obs_sceneitem_set_visible(txt_item, False)
            
            if force_default_pos:
                # Medidas y Posición extraídas de la imagen (Pantalla 1920x1080)
                # Izquierda: 662px, Arriba: 114px, Ancho: 595px, Alto: 134px
                pos = obs.vec2()
                pos.x = 662
                pos.y = 114
                
                source = obs.obs_sceneitem_get_source(img_item)
                sw = obs.obs_source_get_width(source)
                sh = obs.obs_source_get_height(source)
                if sw > 0 and sh > 0:
                    scale = obs.vec2()
                    scale.x = 595.0 / sw
                    scale.y = 134.0 / sh
                    obs.obs_sceneitem_set_alignment(img_item, 5) # Top-Left alignment
                    obs.obs_sceneitem_set_pos(img_item, pos)
                    obs.obs_sceneitem_set_scale(img_item, scale)
            
            obs.obs_sceneitem_get_pos(img_item, img_base_pos)
            obs.obs_sceneitem_get_scale(img_item, img_base_scale)
            
            if abs(img_base_scale.x) < 0.05:
                img_base_scale.x = abs(img_base_scale.y) if img_base_scale.y != 0 else 1.0
                obs.obs_sceneitem_set_scale(img_item, img_base_scale)
                
            bases_init = True
            
        obs.obs_sceneitem_get_pos(img_item, img_base_pos)
            
        if elapsed >= interval_sec:
            state = 1
            state_start_time = now
            
            cx, cy = center_of_item(img_item)
            txt_p = obs.vec2()
            txt_p.x, txt_p.y = cx, cy
            obs.obs_sceneitem_set_pos(txt_item, txt_p)
            
            pos = obs.vec2()
            pos.x = img_base_pos.x
            pos.y = img_base_pos.y - slide_distance
            obs.obs_sceneitem_set_pos(img_item, pos)
            
            obs.obs_sceneitem_set_visible(img_item, True)

    elif state == 1: # Cayendo
        progress = elapsed / anim_slide_dur
        if progress >= 1.0:
            progress = 1.0
            state = 2
            state_start_time = now
            
        t = ease_out_bounce(progress)
        
        pos = obs.vec2()
        pos.x = img_base_pos.x
        pos.y = img_base_pos.y - slide_distance + (slide_distance * t)
        
        obs.obs_sceneitem_set_pos(img_item, pos)
        obs.obs_sceneitem_set_scale(img_item, img_base_scale)
        obs.obs_sceneitem_set_visible(img_item, True)

    elif state == 2: # Mostrando Imagen
        if elapsed >= img_duration_sec:
            state = 3
            state_start_time = now
            
        obs.obs_sceneitem_get_pos(img_item, img_base_pos)
        obs.obs_sceneitem_get_scale(img_item, img_base_scale)
        cx, cy = center_of_item(img_item)
        txt_p = obs.vec2()
        txt_p.x, txt_p.y = cx, cy
        obs.obs_sceneitem_set_pos(txt_item, txt_p)

    elif state == 3: # Girando a Texto (Mitad 1)
        progress = elapsed / anim_flip_dur
        if progress >= 1.0:
            progress = 1.0
            state = 4
            state_start_time = now
            obs.obs_sceneitem_set_visible(img_item, False)
            obs.obs_sceneitem_set_visible(txt_item, True)
            
        t = ease_in_out_sine(progress)
        align = obs.obs_sceneitem_get_alignment(img_item)
        scale_horizontal_centered(img_item, img_base_pos, img_base_scale, img_w, align, 1.0 - t)

    elif state == 4: # Girando a Texto (Mitad 2)
        progress = elapsed / anim_flip_dur
        if progress >= 1.0:
            progress = 1.0
            state = 5
            state_start_time = now
            
        t = ease_in_out_sine(progress)
        tx_scale = obs.vec2()
        tx_scale.x = t
        tx_scale.y = 1.0
        obs.obs_sceneitem_set_scale(txt_item, tx_scale)

    elif state == 5: # Mostrando Texto
        if elapsed >= txt_duration_sec:
            state = 6
            state_start_time = now

    elif state == 6: # Girando de vuelta a imagen (Mitad 1)
        progress = elapsed / anim_flip_dur
        if progress >= 1.0:
            progress = 1.0
            state = 7
            state_start_time = now
            obs.obs_sceneitem_set_visible(txt_item, False)
            obs.obs_sceneitem_set_visible(img_item, True)
            
        t = ease_in_out_sine(progress)
        tx_scale = obs.vec2()
        tx_scale.x = 1.0 - t
        tx_scale.y = 1.0
        obs.obs_sceneitem_set_scale(txt_item, tx_scale)
        
    elif state == 7: # Girando de vuelta a imagen (Mitad 2)
        progress = elapsed / anim_flip_dur
        if progress >= 1.0:
            progress = 1.0
            state = 8
            state_start_time = now
            
        t = ease_in_out_sine(progress)
        align = obs.obs_sceneitem_get_alignment(img_item)
        scale_horizontal_centered(img_item, img_base_pos, img_base_scale, img_w, align, t)

    elif state == 8: # Subiendo para desaparecer
        progress = elapsed / anim_slide_dur
        if progress >= 1.0:
            progress = 1.0
            state = 0
            state_start_time = now
            obs.obs_sceneitem_set_visible(img_item, False)
            
            obs.obs_sceneitem_set_pos(img_item, img_base_pos)
            obs.obs_sceneitem_set_scale(img_item, img_base_scale)
            obs.obs_source_release(current_scene_source)
            return
            
        t = ease_in_back(progress)
        
        pos = obs.vec2()
        pos.x = img_base_pos.x
        pos.y = img_base_pos.y - (slide_distance * t)
        
        obs.obs_sceneitem_set_pos(img_item, pos)
        
    obs.obs_source_release(current_scene_source)

# ========================================================
# Hooks del Script
# ========================================================

def script_description():
    return (
        "<b><center><h2>Anuncio Animado 3D (Completamente Automático)</h2></center></b><br/>"
        "Este script muestra tu imagen y la anima cayendo, esperando un momento de exposición y luego rotando tridimensionalmente para revelar un texto dinámico.<br/><br/>"
        
        "<b><span style='color: #00FF00;'>⬇ INSTRUCCIONES DE USO ⬇</span></b><br/>"
        "<ol>"
        "<li>Agrega tu imagen como una fuente estándar en tu escena de OBS y escógela en la opción debajo: <b>'Fuente de Imagen a animar'</b>.</li>"
        "<li>Escribe el texto de promoción, puedes dar Enter para escribir en múltiples líneas. Escoge a tu gusto su color y tipografía.</li>"
        "<li>Configura los tiempos a tu agrado en los ajustes de abajo (Espera y Duraciones).</li>"
        "<li>Para mover la publicidad <b>desmarca la casilla</b> de tamaño predeterminado, muévela libremente, y automáticamente todo se reajustará al texto.</li>"
        "</ol><br/>"
        "<i>*No tienes que crear fuentes extra, el script administrará todo.</i><br/><br/>"
        "<hr/>"
        "<b>¿Problemas o Dudas?</b><br/>"
        "Contacta por Discord a: <span style='color: #5865F2;'><b>TheGeek190#2960</b></span>"
    )

def script_update(settings):
    # Uso un nuevo set de variables para eludir cualquier caché sucia de crasheos pasados por el string mismatch
    global image_source_name, text_content, text_color, font_data, align_mode
    global interval_sec, img_duration_sec, txt_duration_sec, slide_distance
    global state, state_start_time, bases_init

    if bases_init and image_source_name:
        current_scene_source = obs.obs_frontend_get_current_scene()
        if current_scene_source:
            parent_scene = obs.obs_scene_from_source(current_scene_source)
            img_item = obs.obs_scene_find_source(parent_scene, image_source_name)
            txt_item = obs.obs_scene_find_source(parent_scene, generated_text_name)
            if img_item:
                obs.obs_sceneitem_set_pos(img_item, img_base_pos)
                obs.obs_sceneitem_set_scale(img_item, img_base_scale)
            if txt_item:
                obs.obs_sceneitem_set_visible(txt_item, False)
            obs.obs_source_release(current_scene_source)

    image_source_name = obs.obs_data_get_string(settings, "image_source")
    text_content = obs.obs_data_get_string(settings, "text_content")
    text_color = obs.obs_data_get_string(settings, "text_color")
    
    # Obtener el String de forma segura
    str_align = obs.obs_data_get_string(settings, "text_alignment_mode")
    align_mode = str_align if str_align else "center"
    
    font_data = obs.obs_data_get_obj(settings, "font_data")
    force_default_pos = obs.obs_data_get_bool(settings, "force_default_pos")
    
    interval_sec = obs.obs_data_get_int(settings, "interval_sec")
    img_duration_sec = obs.obs_data_get_int(settings, "img_duration_sec")
    txt_duration_sec = obs.obs_data_get_int(settings, "txt_duration_sec")
    
    state = 0
    state_start_time = 0
    bases_init = False
    
    obs.timer_remove(animation_tick)
    
    if image_source_name:
        obs.timer_add(animation_tick, 16)

def script_properties():
    props = obs.obs_properties_create()
    
    p_img = obs.obs_properties_add_list(props, "image_source", "Fuente de Imagen a animar", obs.OBS_COMBO_TYPE_EDITABLE, obs.OBS_COMBO_FORMAT_STRING)
    
    sources = obs.obs_enum_sources()
    if sources is not None:
        for source in sources:
            source_id = obs.obs_source_get_unversioned_id(source)
            name = obs.obs_source_get_name(source)
            if source_id == "image_source":
                obs.obs_property_list_add_string(p_img, name, name)
        obs.source_list_release(sources)
        
    obs.obs_properties_add_text(props, "text_content", "Mensaje detrás de la imagen:", obs.OBS_TEXT_MULTILINE)
    
    # Nuevo identificador interno para la lista de Alineación para que OBS no mezcle tipos antiguos (el causante del crash)
    p_align = obs.obs_properties_add_list(props, "text_alignment_mode", "Alineación del Texto", obs.OBS_COMBO_TYPE_LIST, obs.OBS_COMBO_FORMAT_STRING)
    obs.obs_property_list_add_string(p_align, "Izquierda", "left")
    obs.obs_property_list_add_string(p_align, "Centro", "center")
    obs.obs_property_list_add_string(p_align, "Derecha", "right")
    
    obs.obs_properties_add_font(props, "font_data", "Fuente del Texto")
    obs.obs_properties_add_text(props, "text_color", "Color del texto (Hex RGB):", obs.OBS_TEXT_DEFAULT)
    
    obs.obs_properties_add_bool(props, "force_default_pos", "Tamaño predeterminado (Bloquea config exacta)")
    
    obs.obs_properties_add_int(props, "interval_sec", "Espera antes de aparecer (seg)", 1, 3600, 1)
    obs.obs_properties_add_int(props, "img_duration_sec", "Duración - Imagen (seg)", 1, 3600, 1)
    obs.obs_properties_add_int(props, "txt_duration_sec", "Duración - Texto (seg)", 1, 3600, 1)
    
    return props

def script_defaults(settings):
    obs.obs_data_set_default_int(settings, "interval_sec", 10)
    obs.obs_data_set_default_int(settings, "img_duration_sec", 4)
    obs.obs_data_set_default_int(settings, "txt_duration_sec", 4)
    obs.obs_data_set_default_string(settings, "text_content", "¡Hostea tu Servidor!\nPromoción válida en fusiora.com")
    obs.obs_data_set_default_string(settings, "text_color", "ffffff")
    obs.obs_data_set_default_string(settings, "text_alignment_mode", "center") # Center default
    obs.obs_data_set_default_bool(settings, "force_default_pos", True)
    
    font_obj = obs.obs_data_create()
    obs.obs_data_set_string(font_obj, "face", "Arial")
    obs.obs_data_set_int(font_obj, "size", 72)
    obs.obs_data_set_int(font_obj, "flags", 1) # Bold
    obs.obs_data_set_default_obj(settings, "font_data", font_obj)
    obs.obs_data_release(font_obj)

def script_unload():
    obs.timer_remove(animation_tick)
    if not image_source_name:
        return
        
    current_scene_source = obs.obs_frontend_get_current_scene()
    if current_scene_source:
        parent_scene = obs.obs_scene_from_source(current_scene_source)
        if parent_scene:
            img_item = obs.obs_scene_find_source(parent_scene, image_source_name)
            if img_item and bases_init:
                obs.obs_sceneitem_set_pos(img_item, img_base_pos)
                obs.obs_sceneitem_set_scale(img_item, img_base_scale)
                obs.obs_sceneitem_set_visible(img_item, True)
        obs.obs_source_release(current_scene_source)
